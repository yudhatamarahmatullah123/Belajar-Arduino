/*******************************************************
   www.team-ichibot.id
   copyright @ 2017 - 10 - 23
   Email : shmukti@team-ichibot.id
   dilarang dicopy atau dipakai atau di perjual belikan
   untuk tujuan komersil tanpa seijin dari masmukti
   atau kamu akan dikutuk menjadi batu
   v2.1 6 Desember 2019
 ********************************************************/

#ifndef ichibotArduinoNano_h
#define ichibotArduinoNano_h

#include <Arduino.h>

// include the library code:
#include <LiquidCrystal_74hc595.h>
#include <Servo.h>
// initialize the library with the numbers of the interface pins
#define pin74hc595_DS     10  //arduino pin 6 connected to DS
#define pin74hc595_ST_CP  7  //arduino pin 7 connected to ST_CP
#define pin74hc595_SH_CP  8  //arduino pin 8 connected to SH_CP
//DS,ST_CP,SH_CP
LiquidCrystal_74hc595 lcd(pin74hc595_DS, pin74hc595_ST_CP, pin74hc595_SH_CP);
//#include <eepromExternal.h>
//eepromExternal EEPROMext;
#include <EEPROM.h>

#define pinButton_OKR   A1
#define pinButton_UPR   A2
#define pinButton_DOWNR A0

#define pinButton_OKL   1
#define pinButton_UPL   0
#define pinButton_DOWNL A3

#define pin_FWD_MOTOR_L 3
#define pin_BWD_MOTOR_L 5
#define pin_FWD_MOTOR_R 6
#define pin_BWD_MOTOR_R 11

#define pin_ENABLE_SENSOR_L 9
#define pin_ENABLE_SENSOR_R 13

#define pin_servo_lift 12
#define pin_servo_grip 2

#define pin_kipas 4

#define ACTIVE_LOW 0
#define ACTIVE_HIGH 1

Servo servo_lift;
Servo servo_grip;

#define TARUH   0
#define NORMAL  1
#define AMBIL   2

#define PID_0 0
#define PID_1 1
#define PID_2 2
#define PID_3 3
#define PID_4 4
#define PID_5 5

#define CP_0 0
#define CP_1 1
#define CP_2 2
#define CP_3 3
#define CP_4 4
#define CP_5 5


#define KIPAS_OFF 0
#define KIPAS_ON  1

#define MOTION ACTION_NOT_USE_SENSOR
#define ACTION ACTION_USE_SENSOR

#define NUM_CP 6

#define BELOK_KIRI            ACTION, -100	, 200
#define BELOK_KANAN           ACTION, 200	, -100
#define LURUS                 ACTION, 100	, 100
#define STOP	              ACTION, 0		, 0

#define TWO_CM  	0
#define THREE_CM 	1
#define MIX 		2
#define FOUR_CM		3




struct dataButton {
  byte OKR, UPR, DOWNR, OKL, UPL, DOWNL;
};

struct dataSensor {
  unsigned int bitValue;
  unsigned int adcValue[12];
};

struct dataPID {
  byte Kp;
  byte Kd;
  byte Ki;
  byte PMax;
  int PMin;
};

struct dataSetting {
  int speed;
  /*
    byte Kp;
    byte Kd;
    byte Ki;
    byte PMax;
    int PMin;*/
  byte numPID;
  byte lineColor;
  byte thisCheckPoint;
  byte checkPoint[NUM_CP];
  byte stopIndex;
  byte fanMode;
  byte buzzerMode;
  byte sensor_linewidth;
  byte sensor_sensivity;
  unsigned int LIMIT_VALUE_SENSOR[12];
  char name[15];
};

struct dataIndex {
  byte action;
  unsigned int sensorBitValue[2];
  byte modeSensor;
  int L, R, D;
  byte SA;
  unsigned int TA;
  byte lineColor;
  /*
    byte Kp;
    byte Kd;
    byte Ki;
    byte PMax;
    int PMin;
  */
  byte fanState, servo_position;
  byte numPID;
};




#define GARIS_HITAM 0
#define GARIS_PUTIH 1

#define ACTION_NOT_USE_SENSOR 1
#define ACTION_USE_SENSOR 0

#define OR    0
#define EQUAL 1
#define XOR   2

#define SENSOR_SEMUA          0b111111111111, 0b000000000000, OR
#define SENSOR_SEMUA_KENA     0b111111111111, 0b000000000000, EQUAL
#define SENSOR_KOSONG         0b000000000000, 0b000000000000, EQUAL
#define SENSOR_KIRI           0b110000000000, 0b000000000000, OR
#define SENSOR_KANAN          0b000000000011, 0b000000000000, OR
#define SENSOR_KIRI_KANAN     0b110000000000, 0b000000000011, XOR
#define SENSOR_KIRI_TENGAH    0b100000000000, 0b000001110000, XOR
#define SENSOR_KANAN_TENGAH   0b000000000001, 0b000011100000, XOR
#define SENSOR_SIKU_KANAN     0b000000000110, 0b000111100000, XOR
#define SENSOR_SIKU_KIRI      0b011000000000, 0b000001111000, XOR


#define TOTAL_INDEX 60
#define NUM_PID 6
dataIndex ramIndexData[TOTAL_INDEX];
dataPID listPID[NUM_PID];

dataSetting setting;

class ichibotArduinoNano {
  private:

  public:
    byte sudutGripperAngkat = 90;
    byte sudutGripperTaruh  = 180;

    byte sudutGripperJepit  = 150;
    byte sudutGripperLepas  = 0;

    unsigned int delayWaitGripper = 1000;
    unsigned int delayMoveGripper = 30;

    void normal () {
      servo_lift.write(sudutGripperTaruh);
      servo_grip.write(sudutGripperLepas);
    }

    void ambil () {
	for(int a = sudutGripperLepas ; a < sudutGripperJepit ; a++){
        servo_grip.write(a);
        delay(delayMoveGripper);
      }
      delay (delayWaitGripper);
      for(int a = sudutGripperTaruh; a > sudutGripperAngkat ; a--){
        servo_lift.write(a);
        delay(delayMoveGripper);
      }
      delay(delayMoveGripper);
    }
    void taruh () {
      for (int a = sudutGripperAngkat ; a < sudutGripperTaruh ; a++){
        servo_lift.write(a);
        delay(delayMoveGripper);
      }
      delay(delayMoveGripper);
      for(int a =sudutGripperJepit; a > sudutGripperLepas; a--){
        servo_grip.write(a);
        delay(delayMoveGripper);
      }
	    delay(delayMoveGripper);
    }

    byte servolastPos = 255;
    void setServo(byte posisi) {
      if (posisi == servolastPos) {
        //donothing
      } else {
        servolastPos = posisi;
        switch (posisi) {
          case TARUH:
            taruh();
            break;
          case NORMAL:
            normal();
            break;
          case AMBIL:
            ambil();
            break;
        }
      }
    }

    void setEnableSensor(byte inL, byte inR) {
      digitalWrite(pin_ENABLE_SENSOR_L, inL);
      digitalWrite(pin_ENABLE_SENSOR_R, inR);
      _delay_us(50);
    }

    dataButton readButton() {
      dataButton btn;
      setEnableSensor(LOW, LOW);
	  _delay_us(20);
      btn.OKR = digitalRead(pinButton_OKR);
      btn.UPR = digitalRead(pinButton_UPR);
      btn.DOWNR = digitalRead(pinButton_DOWNR);
      btn.OKL = digitalRead(pinButton_OKL);
      btn.UPL = digitalRead(pinButton_UPL);
      btn.DOWNL = digitalRead(pinButton_DOWNL);
      setEnableSensor(HIGH, HIGH);
      return btn;
    };

    dataSensor readSensor() {
      byte pinSensor[12] = {A0, A1, A2, A3, A4, A5, A5, A4, A3, A2, A1, A0};
      unsigned int dataSensorBit = 0;
      unsigned int valSensor[12];
      setEnableSensor(LOW, HIGH);
      delayMicroseconds(100);
      for (int i = 0; i < 6; i++) {
        valSensor[i + 6] = analogRead(pinSensor[i + 6]);
        if ( valSensor[i + 6] > setting.LIMIT_VALUE_SENSOR[i + 6]) {
          dataSensorBit = dataSensorBit  + (0b000000000001 << (5 - i));
        }
      }
      setEnableSensor(HIGH, LOW);
      delayMicroseconds(100);
      for (int i = 5; i >= 0 ; i--) {
        valSensor[i] = analogRead(pinSensor[i]);
        if (valSensor[i] > setting.LIMIT_VALUE_SENSOR[i]) {
          dataSensorBit =  dataSensorBit + (0b000001000000 << (5 - i));
        }
      }
      setEnableSensor(HIGH, HIGH);
      dataSensor sensor;
      if (setting.lineColor == GARIS_PUTIH) {
        sensor.bitValue = 0b111111111111 - dataSensorBit;
      } else {
        sensor.bitValue = dataSensorBit;
      };
      memcpy(sensor.adcValue, valSensor, sizeof(sensor.adcValue));
      return sensor;
    }


    void setMotor(int L, int R) {
      byte PWM;

	if (R > 0) {
		PWM = (255 - R);
		analogWrite(pin_FWD_MOTOR_R, PWM);
		analogWrite(pin_BWD_MOTOR_R, 255);
		} else {
			PWM = (255 + R);
			analogWrite(pin_FWD_MOTOR_R, 255 );
			analogWrite(pin_BWD_MOTOR_R, PWM);
		}

	if (L > 0) {
		PWM = (255 - L);
		analogWrite(pin_FWD_MOTOR_L, PWM);
		analogWrite(pin_BWD_MOTOR_L, 255);
		} else {
			PWM = (255 + L);
			analogWrite(pin_FWD_MOTOR_L, 255);
			analogWrite(pin_BWD_MOTOR_L, PWM);
		}
    }


    void displaySensor(unsigned int inp) {
      for (int i = 0; i < 12; i++) {
        lcd.setCursor(13 - i, 0);
        if ((inp >> i) & 0x01 ) {
          lcd.write(0xff);
        } else {
          lcd.print("_");
        }
      }
    }

    void readSetting() {

      EEPROM.get(0, setting);

    }

    void writeSetting() {
      EEPROM.put(0, setting);
    }

    void calibrate_sensor() {
      int xCursor = 0;
      const int numSensor = 12;
      unsigned int minVal[numSensor], maxVal[numSensor];
      lcd.clear();
      delay(200);
      for (int i = 0; i < numSensor; i++) {
        minVal[i] = 1023;
        maxVal[i] = 0;
      }
      while (1) {
        dataSensor sensor = readSensor();
        for (int i = 0; i < numSensor; i++) {
          if (sensor.adcValue[i] > maxVal[i]) {
            maxVal[i]  = sensor.adcValue[i];
          }
          if (sensor.adcValue[i] < minVal[i]) {
            minVal[i]  = sensor.adcValue[i];
          }
        }
        dataButton btn = readButton();
        if (!btn.OKR || !btn.OKL) {
          break;
        }
        lcd.setCursor(0, 0);
        lcd.print("Calibrate Sensor");
        if (millis() % 10 == 0) {
          lcd.setCursor(xCursor, 1);
          lcd.write(0xff);
          if (++xCursor > 16) {
            xCursor = 0;
            lcd.clear();
          }
        }
      }
      for (int i = 0; i < numSensor; i++) {
        setting.LIMIT_VALUE_SENSOR[i] = ((maxVal[i] - minVal[i]) * (float)((100.0 - setting.sensor_sensivity)/100.0)) + minVal[i];
      }
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Saving...");
      writeSetting();
      delay(500);
      lcd.clear();
    }
	void setSensorSensivity(byte sensivity){
		setting.sensor_sensivity = sensivity;
		writeSetting();

	}
	void setLimitSensorManual(unsigned int s0,unsigned int s1,unsigned int s2,unsigned int s3,unsigned int s4,
	unsigned int s5,unsigned int s6,unsigned int s7,unsigned int s8,unsigned int s9,unsigned int s10,unsigned int s11 ){
		setting.LIMIT_VALUE_SENSOR[0] = s0;
		setting.LIMIT_VALUE_SENSOR[1] = s1;
		setting.LIMIT_VALUE_SENSOR[2] = s2;
		setting.LIMIT_VALUE_SENSOR[3] = s3;
		setting.LIMIT_VALUE_SENSOR[4] = s4;
		setting.LIMIT_VALUE_SENSOR[5] = s5;
		setting.LIMIT_VALUE_SENSOR[6] = s6;
		setting.LIMIT_VALUE_SENSOR[7] = s7;
		setting.LIMIT_VALUE_SENSOR[8] = s8;
		setting.LIMIT_VALUE_SENSOR[9] = s9;
		setting.LIMIT_VALUE_SENSOR[10] = s10;
		setting.LIMIT_VALUE_SENSOR[11] = s11;
		writeSetting();
	}

    void setFan(byte state) {
      if (setting.fanMode == ACTIVE_LOW) {
        digitalWrite(pin_kipas, state > 0 ? LOW : HIGH);
      } else {
        digitalWrite(pin_kipas, state > 0 ? HIGH : LOW);
      }
    }

    void setFanMode(byte activeMode) {
      setting.fanMode = activeMode;
      setFan(LOW);
    }

	void setBuzzer(byte state) {
	  lcd.pinOut(state);
    }

    void setBuzzerMode(byte activeMode) {
      setting.buzzerMode = activeMode;
      setBuzzer(LOW);
    }


    void begin() {

      pinMode(pinButton_OKL, INPUT_PULLUP);
      pinMode(pinButton_UPL, INPUT_PULLUP);

	  pinMode(pinButton_OKR,INPUT);
	  pinMode(pinButton_UPR,INPUT);
	  pinMode(pinButton_DOWNR,INPUT);
	  pinMode(pinButton_DOWNL,INPUT);

      pinMode(pin_FWD_MOTOR_L, OUTPUT);
      pinMode(pin_BWD_MOTOR_L, OUTPUT);
      pinMode(pin_FWD_MOTOR_R, OUTPUT);
      pinMode(pin_BWD_MOTOR_R, OUTPUT);

      lcd.begin(16, 2);
      lcd.pinOut(LOW);
      lcd.backlight(HIGH);
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Ichibot      ");
      lcd.setCursor(0, 1);
      lcd.print("Arduino Nano ");
      delay(1000);
      lcd.clear();

      readSetting();

      if (strcmp(setting.name, "ichibot") != 0) {
        strcpy(setting.name, "ichibot");
        //memset(setting.LIMIT_VALUE_SENSOR, 150, sizeof(setting.LIMIT_VALUE_SENSOR));
		setting.LIMIT_VALUE_SENSOR[0] = 200;
		setting.LIMIT_VALUE_SENSOR[1] = 200;
		setting.LIMIT_VALUE_SENSOR[2] = 200;
		setting.LIMIT_VALUE_SENSOR[3] = 200;
		setting.LIMIT_VALUE_SENSOR[4] = 200;
		setting.LIMIT_VALUE_SENSOR[5] = 200;
		setting.LIMIT_VALUE_SENSOR[6] = 200;
		setting.LIMIT_VALUE_SENSOR[7] = 200;
		setting.LIMIT_VALUE_SENSOR[8] = 200;
		setting.LIMIT_VALUE_SENSOR[9] = 200;
		setting.LIMIT_VALUE_SENSOR[10] = 200;
		setting.LIMIT_VALUE_SENSOR[11] = 200;
        setting.speed = 90;
        //setting.Kp = 10;
        //setting.Kd = 90;
		setting.sensor_sensivity =45;
        setting.thisCheckPoint = 0;
        setting.numPID = 0;
        writeSetting();
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("Reset Default");
        delay(1500);
        lcd.clear();

      }

      servo_lift.attach(pin_servo_lift);
      servo_grip.attach(pin_servo_grip);

      pinMode(pin_kipas, OUTPUT);
      setFan(LOW);
      setServo(NORMAL);

      setEnableSensor(LOW, LOW);

      lcd.pinOut(HIGH);
      lcd.backlight(LOW);
      delay(300);
      lcd.pinOut(LOW);
      lcd.backlight(HIGH);
      setMotor(0, 0);

      setting.lineColor = ramIndexData[0].lineColor;

    }

    void setCheckPoint(byte num, byte index) {
      if (num < NUM_CP) {
        setting.checkPoint[num] = index;
      }
    }

    void setStopIndex(byte index) {
      setting.stopIndex = index;
    }

	void setLineWidth(byte width) {
      setting.sensor_linewidth = width;
    }

    void setPID(byte num, byte Kp, byte Ki, byte Kd, byte PMax, int PMin) {
      if (num < NUM_PID) {
        listPID[num].Kp = Kp;
        listPID[num].Ki = Ki;
        listPID[num].Kd = Kd;
        listPID[num].PMax = PMax;
        listPID[num].PMin = PMin;
      }
    }

    void setIndex(byte index, byte action,  int L , int R , unsigned int D , unsigned int sensor0, unsigned int sensor1, byte modeSensor,
                  byte SA = 150, unsigned int TA  = 0, byte numPID = 0, byte lineColor = GARIS_HITAM, byte kipas = 0, byte servo_pos = NORMAL) {
      ramIndexData[index].sensorBitValue[0] = sensor0;
      ramIndexData[index].sensorBitValue[1] = sensor1;
      ramIndexData[index].L = L;
      ramIndexData[index].R = R;
      ramIndexData[index].D = D;
      ramIndexData[index].SA = SA;
      ramIndexData[index].TA = TA;
      ramIndexData[index].modeSensor = modeSensor;
      ramIndexData[index].action = action;
      ramIndexData[index].numPID = numPID;
      ramIndexData[index].fanState = kipas;
      ramIndexData[index].servo_position = servo_pos;
      ramIndexData[index].lineColor = lineColor;
    }

    void finish(byte nstep) {
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("STOP...");
      lcd.setCursor(0, 1);
      lcd.print("STEP:");
      lcd.print(nstep);
      lcd.print("  ");
      setMotor(0, 0);
      delay(1500);
      lcd.clear();

    }
    void show_display_index (byte nstep) {
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Running...");
      lcd.setCursor(0, 1);
      lcd.print("Index:");
      lcd.print(nstep);
    }

    int error = 0;
    int lastError = 0;
    //long unsigned int deltaT = 0;

	double lastProcess = 0;
	double P = 0;
	double D = 0;
	double I = 0;

    void followLine() {

		double deltaTime = (millis() - lastProcess) / 1000.0;
    lastProcess = millis();
		dataSensor sensor = readSensor();

		if (setting.sensor_linewidth == TWO_CM || setting.sensor_linewidth == MIX) { // 2cm or mix
		  switch (sensor.bitValue) {
			case 0b000000000001: error = -18;  break;
			case 0b000000000011: error = -16;  break;
			case 0b000000000010: error = -12;  break;
			case 0b000000000110: error = -10;  break;
			case 0b000000000100: error = -8;  break;
			case 0b000000001100: error = -6;  break;
			case 0b000000001000: error = -5;  break;
			case 0b000000011000: error = -4;  break;
			case 0b000000010000: error = -3;  break;
			case 0b000000110000: error = -2;   break;
			case 0b000000100000: error = -1;   break;
			case 0b000001100000: error = 0;   break;
			case 0b000001000000: error = 1;   break;
			case 0b000011000000: error = 2;   break;
			case 0b000010000000: error = 3;   break;
			case 0b000110000000: error = 4;   break;
			case 0b000100000000: error = 5;   break;
			case 0b001100000000: error = 6;   break;
			case 0b001000000000: error = 8;   break;
			case 0b011000000000: error = 10;  break;
			case 0b010000000000: error = 12;  break;
			case 0b110000000000: error = 16;  break;
			case 0b100000000000: error = 18;  break;
		  }
		}

		if (setting.sensor_linewidth == THREE_CM || setting.sensor_linewidth == MIX) { // 3cm or mix
		  switch (sensor.bitValue) {
			case 0b000000000001: error = -11; break;
			case 0b000000000011: error = -10;  break;
			case 0b000000000111: error = -8;  break;
			case 0b000000001110: error = -6;  break;
			case 0b000000011100: error = -4;  break;
			case 0b000000111000: error = -2;   break;
			case 0b000001110000: error = -1;   break;
			case 0b000011110000: error = 0;   break;
			case 0b000001100000: error = 0;   break;
			case 0b000011100000: error = 1;   break;
			case 0b000111000000: error = 2;   break;
			case 0b001110000000: error = 4;   break;
			case 0b011100000000: error = 6;   break;
			case 0b111000000000: error = 8;  break;
			case 0b110000000000: error = 10;  break;
			case 0b100000000000: error = 11;  break;
		  }
		}
		if (setting.sensor_linewidth == FOUR_CM || setting.sensor_linewidth == MIX) { // 3cm or mix
		  switch (sensor.bitValue) {
			case 0b000000000001: error = -10; break;
			case 0b000000000011: error = -9;  break;
			case 0b000000000111: error = -8;  break;
			case 0b000000001111: error = -6;  break;
			case 0b000000011110: error = -4;   break;
			case 0b000000111100: error = -2;   break;
			case 0b000001111000: error = -1;   break;
			case 0b000011110000: error = 0;   break;
			case 0b000111100000: error = 1;  break;
			case 0b001111000000: error = 2;  break;
			case 0b011110000000: error = 4;  break;
			case 0b111100000000: error = 6;  break;
			case 0b111000000000: error = 8;  break;
			case 0b110000000000: error = 9;  break;
			case 0b100000000000: error = 10;  break;
		  }
		}

		P = error * (double) listPID[setting.numPID].Kp;
    D = (error - lastError) * (double) listPID[setting.numPID].Kd / deltaTime;

		I =0;

		int rateError = error - lastError;
		lastError = error;
		int moveVal = (int)P + (int)I + (int)D;
		int moveLeft = setting.speed - moveVal;
		int moveRight = setting.speed + moveVal;
		int minSpeed = listPID[setting.numPID].PMin;
		int maxSpeed = listPID[setting.numPID].PMax;

		if (moveLeft < minSpeed)  moveLeft = minSpeed;
        if (moveLeft > maxSpeed)  moveLeft = maxSpeed;
        if (moveRight < minSpeed)  moveRight = minSpeed;
        if (moveRight > maxSpeed)  moveRight = maxSpeed;

		setMotor(moveLeft, moveRight);

	}

	void calibrateSensorManual(){
		lcd.clear();
		delay(200);
      dataButton btn;
	   byte pinSensor[12] = {A0, A1, A2, A3, A4, A5, A5, A4, A3, A2, A1, A0};
	  int i =0;
      while (1) {
        dataSensor sensor = readSensor();
        displaySensor(sensor.bitValue);
        btn = readButton();

        char buff[16];
        sprintf(buff, "A:%02d L:%04d %04d", i+1, setting.LIMIT_VALUE_SENSOR[i],analogRead(pinSensor[i]) );
		lcd.setCursor(0, 1);
        lcd.print(buff);

		if(!btn.OKL){
			lcd.clear();
			delay(300);
			break;
		}
		if(!btn.UPL){
			i++;
			if(i>11) i =0;
			delay(200);
		}
		if(!btn.DOWNL){
			i--;
			if(i<0) i =11;
			delay(200);
		}
		if(!btn.UPR){
			 setting.LIMIT_VALUE_SENSOR[i]+=5;
			if(setting.LIMIT_VALUE_SENSOR[i]>1023L){
				i =0;
			}
			writeSetting();
			delay(100);
		}
		if(!btn.DOWNR){
			 setting.LIMIT_VALUE_SENSOR[i]-=5;
			if( setting.LIMIT_VALUE_SENSOR[i]<0){
				setting.LIMIT_VALUE_SENSOR[i] =1023;
			}
			writeSetting();
			delay(100);
		}
	  }

	}

    void run() {
      dataButton btn;
      while (1) {
        dataSensor sensor = readSensor();
        displaySensor(sensor.bitValue);
        btn = readButton();

        char buff[16];
        sprintf(buff, "CP:%02d i:%02d V:%03d", setting.thisCheckPoint, setting.checkPoint[setting.thisCheckPoint], setting.speed);
        lcd.setCursor(0, 1);
        lcd.print(buff);

        if (!btn.DOWNR) {
          setting.speed--;
          delay(100);
          writeSetting();
        }
        if (!btn.UPR) {
          setting.speed++;
          delay(100);
          writeSetting();
        }
        if (setting.speed > 255 ) {
          setting.speed = 0;
        }
        if (setting.speed < 0 ) {
          setting.speed = 255;
        }

        if (!btn.DOWNL) {
          setting.thisCheckPoint--;
          delay(100);
          writeSetting();
        }
        if (!btn.UPL) {
          setting.thisCheckPoint++;
          delay(100);
          writeSetting();
        }
        if (setting.thisCheckPoint >= NUM_CP ) {
          setting.thisCheckPoint = 0;
        }
        if (setting.thisCheckPoint < 0 ) {
          setting.thisCheckPoint  = NUM_CP - 1;
        }

        if (!btn.OKL) {
          calibrate_sensor();
        }
        if (!btn.OKR) {
          lcd.clear();
          while (!btn.OKR) {
            btn = readButton();
            lcd.setCursor(0, 0);
            lcd.print("Ready...");
          };
          break;
        }
      }
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Run Away...");

      //start dimulai
      int Step = 1;
      setMotor(100, 100);
      delay(100);

      byte thisRunIndex = setting.checkPoint[setting.thisCheckPoint];
      dataIndex mem  = ramIndexData[thisRunIndex];

      setting.lineColor = mem.lineColor;

      int normalSpeed =  setting.speed;
      int timerSpeed;
      long timer;
      dataSensor sensor;
      while (1) {
        mem  = ramIndexData[thisRunIndex];
        sensor = readSensor();
        byte do_action = 0;
        if ( mem.action == ACTION_NOT_USE_SENSOR) {
          do_action = 1;
        } else if (mem.action == ACTION_USE_SENSOR ) {
          if ( mem.modeSensor == XOR) {
            if (sensor.bitValue & mem.sensorBitValue[0]){
					if (sensor.bitValue & mem.sensorBitValue[1])  { // syarat untuk step 1
						do_action = 2;
					}
            }
          } else if (mem.modeSensor == OR) {
            if (sensor.bitValue & mem.sensorBitValue[0]) { // syarat untuk step 1
              do_action = 3;
            }
          } else if (mem.modeSensor == EQUAL) {
            if (sensor.bitValue == mem.sensorBitValue[0]) { // syarat untuk step 1
              do_action = 4;
            }
          }
        }
        if (do_action) {
		  lcd.backlight(HIGH);
		  if (setting.buzzerMode){
			  setBuzzer(HIGH);
		  }
          show_display_index(thisRunIndex);
          if (thisRunIndex>0){
            if ((ramIndexData[thisRunIndex].L > 0) && (ramIndexData[thisRunIndex].L > 0)){
            } else if (ramIndexData[thisRunIndex].lineColor != ramIndexData[thisRunIndex+1].lineColor){
            }
            else {
            //setMotor(-130, -130);
             //delay(50);
            }
          }
		  setMotor(mem.L, mem.R);
          delay(mem.D);
          //setFan(mem.fanState);
          //setServo(mem.servo_position);


		  if (mem.action == ACTION_USE_SENSOR ){
			  sensor = readSensor();
			  while(sensor.bitValue == 0){
				sensor = readSensor();
			  }
		  }

          timer = mem.TA;
          timerSpeed = mem.SA;
          setting.numPID = mem.numPID;
          setting.lineColor = mem.lineColor;

          long lastmsg = millis();
		  while ((millis()  - lastmsg) < (timer * 50)) {
			setting.speed = timerSpeed;
            lcd.backlight(HIGH);
            followLine();
          }
          timer = 0;
		  setFan(mem.fanState);
          setServo(mem.servo_position);
          setting.speed = normalSpeed;
          lcd.backlight(LOW);
		      setBuzzer(LOW);
          if (thisRunIndex == setting.stopIndex ) {
            finish(thisRunIndex);
            thisRunIndex = 0;
            setting.lineColor = ramIndexData[0].lineColor;
            break;

          }
          thisRunIndex ++;
        }
        followLine();
		if (!digitalRead(pinButton_OKL )) {
            finish(thisRunIndex-1);
            break;
          }
      }
      lcd.pinOut(LOW);
      lcd.backlight(HIGH);
    }

};
#endif
