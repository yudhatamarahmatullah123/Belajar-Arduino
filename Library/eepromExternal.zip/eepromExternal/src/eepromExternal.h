/*****************************************************
   EEPROM I2C
   code by: shmukti (shmukti.team-ichibot.com,cc:harimukti.selalu@gmail.com);
   rev 0
   2016/12/29

   Code for write and read data from external i2c EEPROM
   Notice: warning maximum address is not checked

   functions usage:
   begin(); to enable i2c communication
   stop(); to disable i2c communication
   read(); read single byte from eeprom
   write(); write single byte to eeprom
        parameter :
        deviceAddress =  i2c addres of startAddressprom
        dataAddress = address of data
   put(); write struct data to eeprom
   get(); get struct data from eeprom
        parameter :
        startAddress =  begin address of eeprom data
        value = struct data
 *****************************************************/
 
#ifndef eepromExternal_h
#define eepromExternal_h

#include <Wire.h>
#include <Arduino.h>

class eepromExternal {
  private:
    int _DEVICE_ADDRESS;
    int _WRITE_DELAY;
  public:
    eepromExternal(int DEVICE_ADDRESS, int WRITE_DELAY);
    eepromExternal(int DEVICE_ADDRESS);
    eepromExternal();
    template <class T> int put(int startAddress, const T& value)
    {
      const byte* p = (const byte*)(const void*)&value;
      unsigned int i;
      for (i = 0; i < sizeof(value); i++)
        write(startAddress++, *p++);
      return i;
    }

    template <class T> int get(int startAddress, T& value)
    {
      byte* p = (byte*)(void*)&value;
      unsigned int i;
      for (i = 0; i < sizeof(value); i++)
        *p++ = read(startAddress++);
      return i;
    }

    void write(unsigned int dataAddress, byte data )
    {
      Wire.beginTransmission(_DEVICE_ADDRESS);
      Wire.write((int)(dataAddress >> 8));   // MSB
      Wire.write((int)(dataAddress & 0xFF)); // LSB
      Wire.write(data);
      Wire.endTransmission();
      delay(_WRITE_DELAY);
    }

    byte read(unsigned int dataAddress )
    {
      byte retval = 0xFF;
      Wire.beginTransmission(_DEVICE_ADDRESS);
      Wire.write((int)(dataAddress >> 8));   // MSB
      Wire.write((int)(dataAddress & 0xFF)); // LSB
      Wire.endTransmission();
      Wire.requestFrom(_DEVICE_ADDRESS, 1);
      if (Wire.available()) retval = Wire.read();
      return retval;
    }
    void begin() {
      Wire.begin();
    }
    void end() {
      Wire.end();
    }
	long length() {
		byte tmp = read(0);
		write(0, 32);
		if (read(0) != 32) return 0; //not available
		int j;
		for (j = 1; j < 128; j ++) {
			byte tmp2 = read(j * 1024);
			write(j * 1024, 55);
			if (read(0) == 55) {
				write(0, tmp);
				return (long)j * 1024;// return size in byte;
			} else {
				write(j * 1024, tmp2);
			}
		}
		return -1;	//overflow
	}
};
#endif

