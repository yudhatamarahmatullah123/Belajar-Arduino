#include <eepromExternal.h>
eepromExternal::eepromExternal() {
  this-> _DEVICE_ADDRESS = 0x50;  //Address default eeprom chip
  this-> _WRITE_DELAY = 5;        //default delay 5 ms
};

eepromExternal::eepromExternal(int DEVICE_ADDRESS) {
  this-> _DEVICE_ADDRESS = DEVICE_ADDRESS;
  this-> _WRITE_DELAY = 5;
};

eepromExternal::eepromExternal(int DEVICE_ADDRESS, int WRITE_DELAY ) {
  this-> _DEVICE_ADDRESS = DEVICE_ADDRESS;
  this-> _WRITE_DELAY = WRITE_DELAY;
};
